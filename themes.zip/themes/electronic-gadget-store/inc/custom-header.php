<?php
/**
 * Custom header implementation
 *
 * @link https://codex.wordpress.org/Custom_Headers
 *
 * @package Electronic Gadget Store
 * @subpackage electronic_gadget_store
 */

function electronic_gadget_store_custom_header_setup() {
    register_default_headers( array(
        'default-image' => array(
            'url'           => get_template_directory_uri() . '/assets/images/header_img.png',
            'thumbnail_url' => get_template_directory_uri() . '/assets/images/header_img.png',
            'description'   => __( 'Default Header Image', 'electronic-gadget-store' ),
        ),
    ) );
}
add_action( 'after_setup_theme', 'electronic_gadget_store_custom_header_setup' );

/**
 * Styles the header image based on Customizer settings.
 */
function electronic_gadget_store_header_style() {
    $electronic_gadget_store_header_image = get_header_image() ? get_header_image() : get_template_directory_uri() . '/assets/images/header_img.png';

    $electronic_gadget_store_height     = get_theme_mod( 'electronic_gadget_store_header_image_height', 350 );
    $electronic_gadget_store_position   = get_theme_mod( 'electronic_gadget_store_header_background_position', 'center' );
    $electronic_gadget_store_attachment = get_theme_mod( 'electronic_gadget_store_header_background_attachment', 1 ) ? 'fixed' : 'scroll';

    $electronic_gadget_store_custom_css = "
        .header-img, .single-page-img, .external-div .box-image-page img, .external-div {
            background-image: url('" . esc_url( $electronic_gadget_store_header_image ) . "');
            background-size: cover;
            height: " . esc_attr( $electronic_gadget_store_height ) . "px;
            background-position: " . esc_attr( $electronic_gadget_store_position ) . ";
            background-attachment: " . esc_attr( $electronic_gadget_store_attachment ) . ";
        }

        @media (max-width: 1000px) {
            .header-img, .single-page-img, .external-div .box-image-page img,.external-div,.featured-image{
                height: 250px !important;
            }
            .box-text h2{
                font-size: 27px;
            }
        }
    ";

    wp_add_inline_style( 'electronic-gadget-store-style', $electronic_gadget_store_custom_css );
}
add_action( 'wp_enqueue_scripts', 'electronic_gadget_store_header_style' );

/**
 * Enqueue the main theme stylesheet.
 */
function electronic_gadget_store_enqueue_styles() {
    wp_enqueue_style( 'electronic-gadget-store-style', get_stylesheet_uri() );
}
add_action( 'wp_enqueue_scripts', 'electronic_gadget_store_enqueue_styles' );