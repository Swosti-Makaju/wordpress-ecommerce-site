<?php

$electronic_gadget_store_tp_theme_css = '';

$electronic_gadget_store_tp_color_option = get_theme_mod('electronic_gadget_store_tp_color_option');

// 1st color
$electronic_gadget_store_tp_color_option = get_theme_mod('electronic_gadget_store_tp_color_option', '#EEAA74');
if ($electronic_gadget_store_tp_color_option) {
	$electronic_gadget_store_tp_theme_css .= ':root {';
	$electronic_gadget_store_tp_theme_css .= '--color-primary1: ' . esc_attr($electronic_gadget_store_tp_color_option) . ';';
	$electronic_gadget_store_tp_theme_css .= '}';
}

//preloader
$electronic_gadget_store_tp_preloader_color1_option = get_theme_mod('electronic_gadget_store_tp_preloader_color1_option');
$electronic_gadget_store_tp_preloader_color2_option = get_theme_mod('electronic_gadget_store_tp_preloader_color2_option');
$electronic_gadget_store_tp_preloader_bg_color_option = get_theme_mod('electronic_gadget_store_tp_preloader_bg_color_option');

if($electronic_gadget_store_tp_preloader_color1_option != false){
$electronic_gadget_store_tp_theme_css .='.center1{';
	$electronic_gadget_store_tp_theme_css .='border-color: '.esc_attr($electronic_gadget_store_tp_preloader_color1_option).' !important;';
$electronic_gadget_store_tp_theme_css .='}';
}
if($electronic_gadget_store_tp_preloader_color1_option != false){
$electronic_gadget_store_tp_theme_css .='.center1 .ring::before{';
	$electronic_gadget_store_tp_theme_css .='background: '.esc_attr($electronic_gadget_store_tp_preloader_color1_option).' !important;';
$electronic_gadget_store_tp_theme_css .='}';
}
if($electronic_gadget_store_tp_preloader_color2_option != false){
$electronic_gadget_store_tp_theme_css .='.center2{';
	$electronic_gadget_store_tp_theme_css .='border-color: '.esc_attr($electronic_gadget_store_tp_preloader_color2_option).' !important;';
$electronic_gadget_store_tp_theme_css .='}';
}
if($electronic_gadget_store_tp_preloader_color2_option != false){
$electronic_gadget_store_tp_theme_css .='.center2 .ring::before{';
	$electronic_gadget_store_tp_theme_css .='background: '.esc_attr($electronic_gadget_store_tp_preloader_color2_option).' !important;';
$electronic_gadget_store_tp_theme_css .='}';
}
if($electronic_gadget_store_tp_preloader_bg_color_option != false){
$electronic_gadget_store_tp_theme_css .='.loader{';
	$electronic_gadget_store_tp_theme_css .='background: '.esc_attr($electronic_gadget_store_tp_preloader_bg_color_option).';';
$electronic_gadget_store_tp_theme_css .='}';
}

// footer-bg-color
$electronic_gadget_store_tp_footer_bg_color_option = get_theme_mod('electronic_gadget_store_tp_footer_bg_color_option');

if($electronic_gadget_store_tp_footer_bg_color_option != false){
$electronic_gadget_store_tp_theme_css .='#footer{';
	$electronic_gadget_store_tp_theme_css .='background: '.esc_attr($electronic_gadget_store_tp_footer_bg_color_option).' !important;';
$electronic_gadget_store_tp_theme_css .='}';
}

// footer widget title color
$electronic_gadget_store_footer_widget_title_color = get_theme_mod('electronic_gadget_store_footer_widget_title_color');
if($electronic_gadget_store_footer_widget_title_color != false){
$electronic_gadget_store_tp_theme_css .='#footer h3, #footer h2.wp-block-heading{';
$electronic_gadget_store_tp_theme_css .='color: '.esc_attr($electronic_gadget_store_footer_widget_title_color).';';
$electronic_gadget_store_tp_theme_css .='}';
}

// copyright text color
$electronic_gadget_store_footer_copyright_text_color = get_theme_mod('electronic_gadget_store_footer_copyright_text_color');
if($electronic_gadget_store_footer_copyright_text_color != false){
$electronic_gadget_store_tp_theme_css .='#footer .site-info p, #footer .site-info a {';
$electronic_gadget_store_tp_theme_css .='color: '.esc_attr($electronic_gadget_store_footer_copyright_text_color).';';
$electronic_gadget_store_tp_theme_css .='}';
}

// header image title color
$electronic_gadget_store_header_image_title_text_color = get_theme_mod('electronic_gadget_store_header_image_title_text_color');
if($electronic_gadget_store_header_image_title_text_color != false){
$electronic_gadget_store_tp_theme_css .='.box-text h2{';
$electronic_gadget_store_tp_theme_css .='color: '.esc_attr($electronic_gadget_store_header_image_title_text_color).';';
$electronic_gadget_store_tp_theme_css .='}';
}

// menu color
$electronic_gadget_store_menu_color = get_theme_mod('electronic_gadget_store_menu_color');
if($electronic_gadget_store_menu_color != false){
$electronic_gadget_store_tp_theme_css .='.main-navigation a{';
$electronic_gadget_store_tp_theme_css .='color: '.esc_attr($electronic_gadget_store_menu_color).';';
$electronic_gadget_store_tp_theme_css .='}';
}