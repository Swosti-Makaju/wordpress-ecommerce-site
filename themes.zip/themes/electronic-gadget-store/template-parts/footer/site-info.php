<?php
/**
 * Displays footer site info
 *
 * @package Electronic Gadget Store
 * @subpackage electronic_gadget_store
 */

?>

<div class="site-info">
    <div class="container">
       <p><?php electronic_gadget_store_credit(); ?> <?php echo esc_html__('By Themespride', 'electronic-gadget-store'); ?> </p>
    </div>
</div>
